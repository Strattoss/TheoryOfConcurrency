rootProject.name = "TraceTheory-GaussianElimination"

